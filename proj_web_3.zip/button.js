window.onload=function(){
    document.getElementById('btn-back').addEventListener('click',()=>{history.back();});
}